// main.cpp
// Problem Set 5b                                 Chris Canal
// Team cansym                                    canal.c@husky.neu.edu
//                                                Sarada Symonds
//                                                symonds.s@husky.neu.edu
//
// Main program file for homework 5b.
// Project 5

#include <iostream>
#include <limits.h>
#include "d_except.h"
#include <list>
#include <fstream>
#include "d_matrix.h"
#include "Graph.h"
#include <list>
#include <queue>
#include <unordered_map>

using namespace std;


//fadsf
class maze
{
   public:
      maze(ifstream &fin);
      void print(int,int,int,int);
      bool isLegal(int i, int j);

      void setMap(int i, int j, int n);
      int getMap(int i, int j) const;
      void mapMazeToGraph(graph &g);
	  bool findPathRecursive(graph &g, int id);
      void findPathNonRecursive(graph &g);
      void print(graph &g, int id);
      bool isPath(graph &g, int n, int cols);
      bool findShortestPath1(graph& g);
      bool findShortestPath2(graph &g);
      bool getSolMap();
      void resetSolutionMap();

      void stackToSolutionMap(std::stack<int> solutionStack);
      bool printPathOnMaze();
      void setSolutionMap(int i, int j);
      void queueToSolutionMap(std::queue<int> solutionQueue);

   private:
      int rows; // number of rows in the maze
      int cols; // number of columns in the maze

      matrix<bool> value;
      matrix<int> solutionMap;
      matrix<int> map;      // Mapping from maze (i,j) values to node index values
};

maze::maze(ifstream &fin)
// Initializes a maze by reading values from fin.  Assumes that the
// number of rows and columns indicated in the file are correct.
{
   fin >> rows;
   fin >> cols;

   char x;

   value.resize(rows,cols);
   for (int i = 0; i <= rows-1; i++)
      for (int j = 0; j <= cols-1; j++)
      {
	 fin >> x;
	 if (x == 'O')
            value[i][j] = true;
	 else
	    value[i][j] = false;
      }

   map.resize(rows,cols);
   solutionMap.resize(rows,cols);
    for (int i = 0; i <= rows-1; i++){
        for (int j = 0; j <= cols-1; j++){
            solutionMap[i][j] = false;
        }
    }
}

void maze::resetSolutionMap(){
    map.resize(rows,cols);
    solutionMap.resize(rows,cols);
    for (int i = 0; i <= rows-1; i++){
        for (int j = 0; j <= cols-1; j++){
            solutionMap[i][j] = false;
        }
    }
}

void maze::print(int goalI, int goalJ, int currI, int currJ)
// Print out a maze, with the goal and current cells marked on the
// board.
{
   cout << endl;

   if (goalI < 0 || goalI > rows || goalJ < 0 || goalJ > cols)
      throw rangeError("Bad value in maze::print");

   if (currI < 0 || currI > rows || currJ < 0 || currJ > cols)
      throw rangeError("Bad value in maze::print");

   for (int i = 0; i <= rows-1; i++)
   {
      for (int j = 0; j <= cols-1; j++)
      {
	 if (i == goalI && j == goalJ)
	    cout << "*";
	 else
	    if (i == currI && j == currJ)
	       cout << "+";
	    else
	       if (value[i][j])
		  cout << " ";
	       else
		  cout << "X";
      }
      cout << endl;
   }
   cout << endl;
}


bool maze::isLegal(int i, int j)
// Return the value stored at the (i,j) entry in the maze.
{
   if (i < 0 || i > rows || j < 0 || j > cols)
      throw rangeError("Bad value in maze::isLegal");

   return value[i][j];
}



// -------------------- Functions that cansym wrote --------------------
void maze::stackToSolutionMap(std::stack<int> solutionStack){
    int current = 0;
    int i;
    int j;
    while (!solutionStack.empty()){
        current = solutionStack.top();
        i = current/cols;
        j = current%cols;
        solutionMap[i][j] = true;
        solutionStack.pop();
    }
}

void maze::queueToSolutionMap(std::queue<int> solutionQueue){
    int current = 0;
    int i;
    int j;
    while (!solutionQueue.empty()){
        current = solutionQueue.front();
        i = current/cols;
        j = current%cols;
        solutionMap[i][j] = true;
        solutionQueue.pop();
    }
}

void maze::setSolutionMap(int i, int j){
    solutionMap[i][j] = true;
}

bool maze::printPathOnMaze(){

    bool solutionFull = true;
    cout << "\n";
   for (int i = 0; i <= rows-1; i++)
   {
      for (int j = 0; j <= cols-1; j++){
            if (solutionMap[i][j]){
               cout << "*";
            } else if (value[i][j]){
              cout << " ";
              solutionFull = false;
            }else{
              cout << "X";
            }

        }
        cout << endl;
    }
    cout << endl;
    return solutionFull;
}

bool maze::getSolMap(){

    bool solutionFull = true;
    for (int i = 0; i <= rows - 1; i++)
    {
       for (int j = 0; j <= cols - 1; j++){
            if (value[i][j] && !solutionMap[i][j]){
              solutionFull = false;
            }
        }
    }
    return solutionFull;
}

void maze::mapMazeToGraph(graph &g)
// Create a graph g that represents the legal moves in the maze m.
{
    int id = 0;
    for(int i = 0; i < rows; i++) {
        for(int j = 0; j < cols; j++) {
            node * n = new node();
            n->setId(id);
            g.addNode(*n);
			setMap(i, j, id);
            id++;
		}
	}

	for(int i = 0; i < rows; i++) {
        for(int j = 0; j < cols; j++) {


			//adds edge to top
            if(i != 0) {
                if(value[i - 1][j] == true) {
                    g.addEdge(map[i][j], map[i][j] - cols, 1);
                }
            }

            //adds edge to right
            if(j != cols - 1) {
                if(value[i][j + 1] == true) {
                    g.addEdge(map[i][j], map[i][j] + 1, 1);
                }
            }

            //adds edge to bottom
            if(i != rows - 1) {
                if(value[i + 1][j] == true) {
                    g.addEdge(map[i][j], map[i][j] + cols, 1);
                }
            }

            //adds edge for left
            if(j != 0) {
                if(value[i][j - 1] == true) {
                    g.addEdge(map[i][j], map[i][j] - 1, 1);
                }
            }
        }
    }
}


void maze::setMap(int i, int j, int n)
// Set mapping from maze cell (i,j) to graph node n.
{
	map[i][j] = n;
}

int maze ::getMap(int i, int j) const
// Return mapping of maze cell (i,j) in the graph.
{
	return map[i][j];
}

int setDirection(int i, int id, int cols){
	if(i == 0) {
		return id - cols;
	} else if(i == 1) {
		return id + 1;
	} else if(i == 2) {
		return id + cols;
	} else {
		return id - 1;
	}
}

bool maze::findPathRecursive(graph &g, int id) {
    //check for path going up
    int dst;
    if(id == g.numNodes() - 1) {
        g.mark(id);
		cout << "\n";
        return true;
    } else {
        for(int i = 0; i < 4; i++)
        //checks the four directions
        {
            dst = setDirection(i, id, cols);
            if(!(dst < 0 | dst >= g.numNodes())) {
                if(!g.isVisited(dst)) {
                    g.visit(id);
                    if(g.isEdge(id, dst)) {
                        if(findPathRecursive(g, dst)) {
                            g.mark(id);
                            return true;
                        }
                    }

                }

            }

        }
        return false;
    }

}

void maze::print(graph &g, int id) {
    int dst;
    int dir;
    if(id == g.numNodes() - 1) {
		cout << "End of path :)\n";
    } else {
        for(int i = 0; i < 4; i++)
        //checks the four directions
        {
            dst = setDirection(i, id, cols);
            if(dst >= 0 && dst < g.numNodes()) {
                if(!g.isVisited(dst) && g.isMarked(dst)) {
                    g.visit(id);
                    dir = dst - id;
                    if(dir == -cols) {
                        cout << "Go up\n";
                        print(g, dst);
                        return;
                    } else if(dir == cols) {
                        cout << "Go down\n";
                        print(g, dst);
                        return;
                    } else if(dir == 1) {
                        cout << "Go right \n";
                        print(g, dst);
                        return;
                    } else if(dir == -1){
                        cout << "go left\n";
                        print(g, dst);
                        return;
                    } else {
                        cout << "bad direction\n";
                    }

                }

            } else if (id != 0 && i == 4) {
                cout << "\nno path\n";
            }

        }
    }
}


void printStack(std::stack<int> theStack){
    int id = 0;
    cout << "{ ";
    while (theStack.size() > 0){
        id = theStack.top();
        theStack.pop();
        cout << id;
        if (theStack.size() == 0){
        } else {
            cout << ", ";
        }
    }
    cout << " }\n";
}

void printQueue(std::queue<int> theQueue){
    int id = 0;
    cout << "{ ";
    while (theQueue.size() > 0){
        id = theQueue.front();
        theQueue.pop();
        cout << id;
        if (theQueue.size() == 0){
        } else {
            cout << ", ";
        }
    }
    cout << " }\n";
}

void maze::findPathNonRecursive(graph &g)
{
    int id = 0;
    int n;
    std::stack<int> pathStack;
    std::stack<int> visitingStack;
    std::stack<int> popNumbers;
    visitingStack.push(id);
    n = visitingStack.top();
    while(!visitingStack.empty()) {
        if(n == g.numNodes() - 1) {
            pathStack.push(n);
            break;
        }
        //cout << "\n n: " << n;
        if(!g.isVisited(n)) {
            g.visit(n);
            if(n + 1 <= (g.numNodes() - 1) && (n + 1) >= 0) {
                if(g.isEdge(n, n + 1) && !g.isVisited(n + 1)) {
                    visitingStack.push(n + 1);
                }
            }
            if(n + cols <= (g.numNodes() - 1) && (n + cols) >= 0) {
                if(g.isEdge(n, n + cols) && !g.isVisited(n + cols)) {
                    visitingStack.push(n + cols);
                }
            }
            if((n - 1) <= (g.numNodes() - 1) && (n - 1) >= 0) {
                if(g.isEdge(n, n - 1) && !g.isVisited(n - 1)) {
                    visitingStack.push(n - 1);
                }
            }
            if((n - cols) <= (g.numNodes() - 1) && (n - cols) >= 0) {
                if(g.isEdge(n, n - cols) && !g.isVisited(n - cols)) {
                    visitingStack.push(n - cols);
                }
            }

        }
        pathStack.push(n);
        if(isPath(g, n, cols)) {
            n = visitingStack.top();
            visitingStack.pop();

        } else {
            while(!isPath(g, n, cols)) {
                pathStack.pop();
                n = pathStack.top();

            }
        }
    }
    stackToSolutionMap(pathStack);
    while(!pathStack.empty()) {
        id = pathStack.top();
        g.mark(id);
        pathStack.pop();
    }
}

bool maze::isPath(graph &g, int n, int cols) {
    int dst;
    bool p = false;
    for(int i = 0; i < 4; i++) {
        if(i == 0) {
            dst = n + 1;
        } else if(i == 1) {
            dst = n + cols;
        } else if(i == 2) {
            dst = n - 1;
        } else {
            dst = n - cols;
        }
        if (dst < g.numNodes() && dst >= 0) {
            if(g.isEdge(n, dst) && !g.isVisited(dst)) {
                p = true;
            }
        }

    }
    return p;

}

bool maze::findShortestPath1(graph& g) {
    std::queue<std::queue<int> > pathQueue;
    std::queue<int> initPath;
    initPath.push(0);
    pathQueue.push(initPath);
    int currId = 0;
    int dst;
    std::queue<int> currPath;
    while(currId != g.numNodes() - 1) {
        currPath = pathQueue.front();
        pathQueue.pop();
        currId = currPath.back();
        g.visit(currId);
        if(currId == g.numNodes() - 1) {
            int idMark;
            while(currPath.size() != 0) {
                idMark = currPath.front();
                g.mark(idMark);
                currPath.pop();
            }
            return true;
        }
        for(int i = 0; i < 4; i++) {
            dst = setDirection(i, currId, cols);
            if(!(dst < 0 | dst >= g.numNodes()) && !g.isVisited(dst)) {
                if(g.isEdge(currId, dst)) {
                        std::queue<int> newPath;
                        newPath = currPath;
                        newPath.push(dst);
                        pathQueue.push(newPath);
                }
            }
        }
    }
    return false;
}

bool maze::findShortestPath2(graph &g) {
    g.setEdgeWeights(1);
    std::unordered_map<int,std::queue<int> > nodeMap;
    int k = 0;
    int currId = 0;
    int dst;
    bool isPath;
    std::queue<int> * initPath;
    std::queue<int> * emptyPath;
    std::queue<int> * newPath;
    std::queue<int> nextNode;
    nextNode.push(0);
    while(k < g.numNodes()) {
        if(k == 0) {
            initPath = new std::queue<int>;
            initPath->push(k);
            nodeMap[k] = *initPath;
        } else {
            emptyPath = new std::queue<int>;
            nodeMap[k] = *emptyPath;
        }
        k++;
    }
    while( !getSolMap() ) {
        //cout << "\nvisiting node: " << currId;
        if (currId < g.numNodes()){
            g.visit(currId);
        } else {
            currId = 1;
            g.clearVisit();
        }
        for(int i = 0; i < 4; i++) {
            dst = setDirection(i, currId, cols);
            if(dst >= 0 && dst < g.numNodes() ) {
                if(g.isEdge(currId, dst)) {
                    if (currId == 0 | nodeMap[currId].size() > 0){
                        newPath = new std::queue<int>;
                        *newPath = nodeMap[currId];
                        newPath->push(dst);
                        queueToSolutionMap(*newPath);
                        if(nodeMap[dst].size() > 0) {
                            if( nodeMap[dst].size() > newPath->size() ) {
                                nodeMap[dst] = *newPath;
                            }
                        } else  {
                            nodeMap[dst] = *newPath;
                        }
                        g.visit(dst);
                        g.visit(currId, dst);

                    }
                }
            }
        }
        currId++;

    }
    g.clearVisit();
    std::queue<int> finalPath;


    finalPath = nodeMap[(g.numNodes() - 1)];
    queueToSolutionMap(finalPath);
    int cur;
    isPath = finalPath.size() != 0;
    while(finalPath.size() != 0) {

        cur = finalPath.front();
        finalPath.pop();
        g.mark(cur);
    }
    return isPath;

}

int main()
{
   char x;
   ifstream fin;
   // Read the maze from the file.
   string fileName = "maze1.txt";
   cout << "\n OPENING: " << fileName << endl;

   fin.open(fileName.c_str());
   if (!fin)
   {
      cerr << "Cannot open " << fileName << endl;
      exit(1);
   }

   try
   {
      graph g3;
      while (fin && fin.peek() != 'Z')
      {
         maze m3(fin);
		 m3.mapMazeToGraph(g3);
		 m3.print(0,0,1,0);
         g3.clearVisit();
         g3.clearMark();
         cout << "\n\nBreadth First Search\n";
         cout << "*-------------------------------------------*\n";
         if(m3.findShortestPath1(g3)) {
             g3.clearVisit();
             m3.print(g3, 0);
             g3.clearVisit();
             g3.clearMark();
         } else {
             cout << "No Path for " << fileName << ".\n";
         }
         cout << "\n\nDijkstra Algorithm Search\n";
         cout << "*-------------------------------------------*\n";
         if(m3.findShortestPath2(g3)) {

             g3.clearVisit();
             m3.print(g3, 0);
             g3.clearVisit();
             g3.clearMark();
         } else {
             cout << "No Path for " << fileName << ".\n";
         }

      }

   }
   catch (indexRangeError &ex)
   {
      cout << ex.what() << endl; exit(1);
   }
   catch (rangeError &ex)
   {
      cout << ex.what() << endl; exit(1);
   }
   fin.close();

   // Read the maze from the file.
  fileName = "maze2.txt";
  cout << "\n\nNOW OPENING: " << fileName << endl;

   fin.open(fileName.c_str());
   if (!fin)
   {
      cerr << "Cannot open " << fileName << endl;
      exit(1);
   }

   try
   {
      graph g2;
      while (fin && fin.peek() != 'Z')
      {
         maze m2(fin);
		 m2.mapMazeToGraph(g2);
		 m2.print(0,0,1,0);
         g2.clearVisit();
         g2.clearMark();
         cout << "Breadth First Search\n";
         cout << "*-------------------------------------------*\n";
		 m2.findShortestPath1(g2);
         g2.clearVisit();
         m2.print(g2, 0);
         g2.clearMark();
         g2.clearVisit();
         cout << "\n\nDijkstra Algorithm Search\n";
         cout << "*-------------------------------------------*\n";
         m2.findShortestPath2(g2);
         g2.clearVisit();
         m2.print(g2, 0);


      }

   }
   catch (indexRangeError &ex)
   {
      cout << ex.what() << endl; exit(1);
   }
   catch (rangeError &ex)
   {
      cout << ex.what() << endl; exit(1);
   }
   fin.close();

   // Read the maze from the file.
  fileName = "maze3.txt";
  cout << "\n\nNOW OPENING: " << fileName << endl;

   fin.open(fileName.c_str());
   if (!fin)
   {
      cerr << "Cannot open " << fileName << endl;
      exit(1);
   }

   try
   {
      graph g;
      while (fin && fin.peek() != 'Z')
      {
         maze m(fin);
		 m.mapMazeToGraph(g);
		 m.print(0,0,1,0);
         g.clearVisit();
         g.clearMark();
         cout << "Breadth First Search\n";
         cout << "*-------------------------------------------*\n";
		 m.findShortestPath1(g);
         g.clearVisit();
         m.print(g, 0);
         g.clearMark();
         g.clearVisit();
         cout << "\n\nDijkstra Algorithm Search\n";
         cout << "*-------------------------------------------*\n";
         m.findShortestPath2(g);
         g.clearVisit();
         m.print(g, 0);


      }

   }
   catch (indexRangeError &ex)
   {
      cout << ex.what() << endl; exit(1);
   }
   catch (rangeError &ex)
   {
      cout << ex.what() << endl; exit(1);
   }



}
